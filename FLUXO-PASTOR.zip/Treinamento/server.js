//PARTE 1

const express = require('express');
const mongoose = require('mongoose');
const path = require('path');


const Usuario = require('./models/Usuario');
const app = express(); 

app.use(express.json());
app.use(express.static('public'));

//INICIA A CONFIGURAÇÃO PARA A SESSÃO
const session = require('express-session');

app.use(session({
  secret: 'seuSegredoUltraSecreto', // troque por algo seguro
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // true só se usar HTTPS
}));

// CONECTA O SERVIDOR NODE.JS AO BANCO DE DADOS MONGODB
// SE ELE NÃO EXISTIR AINDA, O MONGODB CRIA AUTOMATICAMENTE QUANDO O USUÁRIO SALVAR O PRIMEIRO DADO.
mongoose.connect('mongodb://localhost:27017/treinamento')
  .then(() => console.log('MongoDB conectado!'))
  .catch(err => console.error('Erro na conexão:', err));


  

// INICIA O SERVIDOR EXPRESS DENTRO DO NODE.JS
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});



app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login', 'login.html'));
});

app.get('/cadastro', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'cadastro', 'cadastro.html'));
});

app.get('/logado', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'logado', 'logado.html'));
});




// FUNÇÃO QUE GERA UM ID  CRESCENTE PARA CADA NOVO REGISTRO
async function gerarCustomId() {
  const ultima = await Usuario.findOne().sort({ customId: -1 });
  return ultima ? ultima.customId + 1 : 1;
}

//PARTE 2

// ROTA PARA SALVAR OS DADOS
app.post('/salvar', async (req, res) => {
  try {
    const { nome, senha } = req.body;

    // AQUI VERIFICA SE JÁ EXISTE UM USUÁRIO ADMINISTRADOR COM O MESMO NOME
    //CONSIDERAMOS QUE nome_INPUT1 SEJA O INPUT COM O NOME DE nome
    const existente = await Usuario.findOne({ nome });
    if (existente) {
      return res.status(409).json({ message: 'Este nome de usuário já está em uso.' });
    }

    
    const customId = await gerarCustomId(); // -> AQUI ELE GERA UM IP FIXO PARA CADA REGISTRO

    const usuario = new Usuario({ customId, nome, senha});
    await usuario.save();

    console.log('Dados salvos:', usuario);
    res.status(201).json({ message: 'Dados salvos com sucesso!' });
  } catch (error) {
    console.error('Erro ao salvar dados:', error);
    res.status(500).json({ message: 'Erro ao salvar dados' });
  }
});



//PARTE 3

app.post('/login', async (req, res) => {
  const { nome, senha } = req.body;
  try {
    const usuario = await Usuario.findOne({ nome: nome });
    if (!usuario || usuario.senha !== senha) {
      return res.status(401).json({ message: 'Usuário ou senha inválidos!' });
    }
    
    else{
       req.session.adminId = usuario.customId;
       req.session.adminNome = usuario.nome;
       res.status(200).json({
        message: 'Login realizado com sucesso!',
        usuario: {
        id: usuario.customId,
        nome: usuario.nome
      }
    });
    }
    
    
  } catch (error) {
    res.status(500).json({ message: 'Erro interno no servidor' });
  }
});


//PARTE 4

app.get('/verificar_sessao_usuario', (req, res) => {
  if (req.session.adminId) {
    res.status(200).json({ logado: true, nome: req.session.adminNome });
  } else {
    res.status(401).json({ logado: false });
  }
});

//PARTE 5

app.post('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      return res.status(500).json({ message: 'Erro ao encerrar sessão' });
    }
    res.clearCookie('connect.sid'); // remove cookie de sessão
    res.status(200).json({ message: 'Logout realizado com sucesso!' });
  });
});


//PARTE 6

// ==========================================
// ROTAS DE API PARA GERENCIAR OS USUÁRIOS NA TABELA
// ==========================================

// ROTA PARA LISTAR TODOS OS USUÁRIOS CADASTRADOS
app.get('/api/membros', async (req, res) => {
  try {
    const usuarios = await Usuario.find().sort({ customId: 1 });
    res.status(200).json(usuarios);
  } catch (error) {
    console.error('Erro ao buscar usuários:', error);
    res.status(500).json({ error: 'Erro ao buscar usuários' });
  }
});

// ROTA PARA ATUALIZAR UM USUÁRIO PELO customId
app.put('/api/membros/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { nome, senha } = req.body;

    const atualizado = await Usuario.findOneAndUpdate(
      { customId: id },
      { nome, senha },
      { new: true }
    );

    if (!atualizado) {
      return res.status(404).json({ success: false, error: 'Usuário não encontrado' });
    }

    res.status(200).json({ success: true, message: 'Atualizado com sucesso!', atualizado });
  } catch (error) {
    console.error('Erro ao atualizar usuário:', error);
    res.status(500).json({ success: false, error: 'Erro ao atualizar' });
  }
});

// ROTA PARA EXCLUIR UM USUÁRIO PELO customId
app.delete('/api/membros/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const removido = await Usuario.findOneAndDelete({ customId: id });

    if (!removido) {
      return res.status(404).json({ success: false, error: 'Usuário não encontrado' });
    }

    res.status(200).json({ success: true, message: 'Excluído com sucesso!' });
  } catch (error) {
    console.error('Erro ao excluir usuário:', error);
    res.status(500).json({ success: false, error: 'Erro ao excluir' });
  }
});