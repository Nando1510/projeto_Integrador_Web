// ==========================================
// 1. ESTADO GLOBAL E CACHE DE MEMBROS
// ==========================================
let listaMembrosCache = [];
let membroSelecionadoId = null;
let suggestedMinistry = null;
let donsAtuaisModal = []; // Array temporário para manipular os dons no modal

// ==========================================
// 2. CARREGAR DADOS DA TABELA
// ==========================================
async function carregarDados() {
    try {
        const resposta = await fetch('/api/membros');
        const dados = await resposta.json();
        listaMembrosCache = dados; // Salva no cache para o modal utilizar

        const corpo = document.getElementById('corpo-tabela');
        corpo.innerHTML = '';

        dados.forEach(item => {
            const tr = document.createElement('tr');
            const id = item.customId; // ID Numérico Sequencial
            const nome = item.name || '';
            const celular = item.phone || '';
            const criadoEm = item.createdAt ? new Date(item.createdAt).toLocaleString('pt-BR') : '';

            tr.innerHTML = `
                <td>${id}</td>
                <td>${nome}</td>
                <td>${celular}</td>
                <td>${criadoEm}</td>
                <td>
                    <span class="icon" onclick="visualizarRegistro(${id})" title="Visualizar">👁️</span>
                    <span class="icon" onclick="iniciarEdicao(this, ${id})" title="Editar">✏️</span>
                    <span class="icon" onclick="excluirRegistro(${id})" title="Excluir">🗑️</span>
                </td>
            `;
            corpo.appendChild(tr);
        });
    } catch (err) {
        console.error('Erro ao carregar dados:', err);
    }
}

// ==========================================
// 3. REGRA DE NEGÓCIO: MATCH DE MINISTÉRIO
// ==========================================
function calculateMinistryMatch(gifts) {
    if (!Array.isArray(gifts)) return null;
    if (gifts.includes('Ensino') || gifts.includes('Liderança')) return 'EBD';
    if (gifts.includes('Música')) return 'Louvor';
    if (gifts.includes('Serviço') || gifts.includes('Diaconia')) return 'Diaconia';
    if (gifts.includes('Hospitalidade') || gifts.includes('Misericórdia')) return 'Recepção';
    return null;
}

function applyMatch() {
    if (!suggestedMinistry) return;
    const select = document.getElementById('modal-select-ministry');
    if (select) select.value = suggestedMinistry;
    const matchBox = document.getElementById('match-suggestion');
    if (matchBox) matchBox.style.display = 'none';
}

// ==========================================
// 4. GERENCIAMENTO DE DONS NO MODAL (ADICIONAR / REMOVER)
// ==========================================
function renderizarDonsModal() {
    const giftsContainer = document.getElementById('modal-gifts');
    if (!giftsContainer) return;
    
    giftsContainer.innerHTML = '';

    if (donsAtuaisModal.length === 0) {
        giftsContainer.innerHTML = '<span style="font-size:0.8rem; color:#64748b;">Nenhum dom mapeado.</span>';
        return;
    }

    donsAtuaisModal.forEach((gift, index) => {
        const tag = document.createElement('span');
        tag.className = 'gift-tag';
        tag.style.display = 'inline-flex';
        tag.style.alignItems = 'center';
        tag.style.gap = '5px';
        tag.innerHTML = `
            ${gift} 
            <span onclick="removerDomModal(${index})" style="cursor: pointer; font-weight: bold; color: #dc2626; margin-left: 3px;" title="Remover dom">&times;</span>
        `;
        giftsContainer.appendChild(tag);
    });
}

function adicionarDomModal() {
    const select = document.getElementById('select-novo-dom');
    if (!select) return;
    
    const novoDom = select.value;

    if (!novoDom) {
        alert('Selecione um dom para adicionar.');
        return;
    }

    if (donsAtuaisModal.includes(novoDom)) {
        alert('Este membro já possui este dom mapeado.');
        return;
    }

    donsAtuaisModal.push(novoDom);
    renderizarDonsModal();
    select.value = ''; // Limpa o seletor
}

function removerDomModal(index) {
    donsAtuaisModal.splice(index, 1);
    renderizarDonsModal();
}

// ==========================================
// 5. VISUALIZAR MEMBRO (ABRIR MODAL DETALHADO)
// ==========================================
function visualizarRegistro(customId) {
    const membro = listaMembrosCache.find(m => Number(m.customId) === Number(customId));
    if (!membro) {
        alert('Membro não encontrado.');
        return;
    }

    membroSelecionadoId = membro.customId;

    // Cabeçalho e Identificação
    document.getElementById('modal-name').textContent = membro.name || 'Nome não informado';
    document.getElementById('modal-role').textContent = membro.role || 'Membro Comungante';
    document.getElementById('modal-avatar').textContent = membro.name ? membro.name[0].toUpperCase() : 'M';
    
    // Alocação Ministerial
    const currentMinistry = Array.isArray(membro.ministry) ? membro.ministry : [membro.ministry || 'Sem Ministério'];
    const ministrySelect = document.getElementById('modal-select-ministry');
    if (ministrySelect) {
        ministrySelect.value = currentMinistry[0] || 'Sem Ministério';
    }

    // Badge de Status
    const statusClass = membro.status === 'danger' ? 'status-danger' : (membro.status === 'warning' ? 'status-warning' : 'status-ok');
    const statusBadgeContainer = document.getElementById('modal-status-badge');
    if (statusBadgeContainer) {
        statusBadgeContainer.innerHTML = `<span class="status-badge ${statusClass}">${membro.statusText || 'Novo Cadastro (MongoDB)'}</span>`;
    }

    // Frequência (Meios de Graça)
    document.getElementById('att-culto').textContent = membro.attendance?.culto || 'Recente';
    document.getElementById('att-ebd').textContent = membro.attendance?.ebd || 'A verificar';
    document.getElementById('att-oracao').textContent = membro.attendance?.oracao || 'A verificar';

    // Dons Mapeados (Carrega para o array temporário e renderiza)
    donsAtuaisModal = Array.isArray(membro.gifts) ? [...membro.gifts] : [];
    renderizarDonsModal();

    // Sugestão Automática (Match de Dom)
    suggestedMinistry = calculateMinistryMatch(donsAtuaisModal);
    const matchBox = document.getElementById('match-suggestion');
    const isSemMin = currentMinistry.length === 0 || currentMinistry.includes('Sem Ministério');
    if (matchBox) {
        if (suggestedMinistry && isSemMin) {
            const nameEl = document.getElementById('match-ministry-name');
            if (nameEl) nameEl.textContent = suggestedMinistry;
            matchBox.style.display = 'flex';
        } else {
            matchBox.style.display = 'none';
        }
    }

    // Riscos / Vulnerabilidades
    const risksContainer = document.getElementById('modal-risks');
    risksContainer.innerHTML = '';
    const riscos = Array.isArray(membro.risks) ? membro.risks : [];
    if (riscos.length === 0) {
        risksContainer.innerHTML = '<li>Aguardando alocação ministerial inicial</li>';
    } else {
        riscos.forEach(risk => {
            const li = document.createElement('li');
            li.textContent = risk;
            risksContainer.appendChild(li);
        });
    }

    // Histórico Pastoral / Timeline
    const timelineContainer = document.getElementById('modal-timeline');
    timelineContainer.innerHTML = '';
    const historico = Array.isArray(membro.history) ? membro.history : [];
    if (historico.length === 0) {
        timelineContainer.innerHTML = '<p style="font-size:0.8rem; color:#64748b;">Nenhum atendimento registrado.</p>';
    } else {
        historico.forEach(h => {
            const item = document.createElement('div');
            item.className = 'timeline-item';
            item.innerHTML = `
                <span class="timeline-date">${h.date || ''}</span>
                <span class="timeline-category">${h.category || 'Atendimento'}</span>
                <div class="timeline-text">${h.text || ''}</div>
            `;
            timelineContainer.appendChild(item);
        });
    }

    // Exibe o modal centralizado
    const modal = document.getElementById('profile-modal');
    if (modal) modal.classList.add('active');
}

function closeModal() {
    const modal = document.getElementById('profile-modal');
    if (modal) modal.classList.remove('active');
}

async function salvarAlteracoesModal() {
    const selectEl = document.getElementById('modal-select-ministry');
    if (!selectEl || !membroSelecionadoId) return;

    const novoMinisterio = selectEl.value;

    try {
        const response = await fetch(`/api/membros/${membroSelecionadoId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                ministry: [novoMinisterio],
                gifts: donsAtuaisModal, // Envia os dons atualizados (com adições e exclusões)
                status: novoMinisterio !== 'Sem Ministério' ? 'ok' : 'warning',
                statusText: novoMinisterio !== 'Sem Ministério' ? 'Ativo e Engajado' : 'Aguardando Encaminhamento'
            })
        });

        if (response.ok) {
            alert('Perfil atualizado com sucesso!');
            closeModal();
            carregarDados();
        } else {
            alert('Erro ao atualizar perfil do membro.');
        }
    } catch (err) {
        console.error(err);
        alert('Erro de conexão ao salvar no servidor.');
    }
}

// ==========================================
// 6. EDIÇÃO INLINE E EXCLUSÃO NA TABELA
// ==========================================
function iniciarEdicao(el, id) {
    const tr = el.closest('tr');
    const cells = tr.querySelectorAll('td');
    
    ['name', 'phone'].forEach((field, idx) => {
        const td = cells[idx + 1];
        const valor = td.textContent;
        td.innerHTML = `<input class="edit-field" id="edit-${field}-${id}" value="${valor}">`;
    });

    el.textContent = '💾';
    el.onclick = () => salvarEdicao(id);
}

async function salvarEdicao(id) {
    const name = document.getElementById(`edit-name-${id}`).value.trim();
    const phone = document.getElementById(`edit-phone-${id}`).value.trim();

    try {
        const res = await fetch(`/api/membros/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, phone })
        });

        const resultado = await res.json();

        if (res.ok && resultado.success) {
            alert('Membro atualizado com sucesso!');
            carregarDados();
        } else {
            alert('Erro ao salvar edição.');
        }
    } catch (err) {
        console.error(err);
        alert('Erro de conexão ao salvar.');
    }
}

async function excluirRegistro(id) {
    if (!confirm('Deseja realmente excluir este membro?')) return;

    try {
        const res = await fetch(`/api/membros/${id}`, { method: 'DELETE' });
        const resultado = await res.json();

        if (res.ok) {
            alert('Membro excluído com sucesso!');
            carregarDados();
        } else {
            alert('Erro ao excluir registro: ' + (resultado.error || 'Erro desconhecido'));
        }
    } catch (err) {
        console.error(err);
        alert('Erro de conexão ao excluir.');
    }
}

// ==========================================
// 7. PESQUISA FILTRADA NA TABELA
// ==========================================
function pesquisando_Dados() {
    const filtro = document.getElementById('pesquisar').value.toLowerCase();
    const linhas = document.querySelectorAll('#corpo-tabela tr');

    const linhaMensagem = document.getElementById('linha-vazia');
    if (linhaMensagem) linhaMensagem.remove();

    let encontrou = false;

    linhas.forEach(tr => {
        if (tr.id === 'linha-vazia') return;
        
        const nome = tr.cells[1] ? tr.cells[1].textContent.toLowerCase() : '';
        const celular = tr.cells[2] ? tr.cells[2].textContent.toLowerCase() : '';
        const corresponde = nome.includes(filtro) || celular.includes(filtro);
        
        tr.style.display = corresponde ? '' : 'none';
        if (corresponde) encontrou = true;
    });

    if (!encontrou) {
        const tbody = document.getElementById('corpo-tabela');
        const tr = document.createElement('tr');
        tr.id = 'linha-vazia';
        tr.classList.add('mensagem-vazia');
        tr.innerHTML = `<td colspan="5">Nenhum registro encontrado.</td>`;
        tbody.appendChild(tr);
    }
}

const inputPesquisa = document.getElementById('pesquisar');
if (inputPesquisa) {
    inputPesquisa.addEventListener('keydown', e => {
        if (e.key === 'Enter') {
            e.preventDefault();
            pesquisando_Dados();
        }
    });
}

// ==========================================
// 8. VERIFICAÇÃO DE SESSÃO E LOGOUT
// ==========================================
fetch('/verificar_sessao_admin')
    .then(res => res.json())
    .then(data => {
        if (!data.logado) {
            alert('Você precisa estar logado como administrador!');
            window.location.href = '../administrador_Login/administrador_Login.html';
        } else {
            const nav = document.querySelector('.navbar .container-fluid');
            if (nav && !nav.querySelector('.navbar-text')) {
                const bemVindo = document.createElement('span');
                bemVindo.classList.add('navbar-text', 'ms-3');
                bemVindo.textContent = `Bem-vindo(a), ${data.nome}`;
                nav.appendChild(bemVindo);
            }
        }
    })
    .catch(err => console.error('Erro ao verificar sessão:', err));

function confirmaSaida() {
    const confirmar = confirm('Deseja realmente sair?');
    if (confirmar) {
        fetch('/logout', { method: 'POST' })
            .then(() => {
                window.location.href = '../fiel_Cadastro/fiel_Cadastro.html';
            })
            .catch(() => {
                window.location.href = '../fiel_Cadastro/fiel_Cadastro.html';
            });
        return false;
    }
    return false;
}

// Inicializa o carregamento dos dados
carregarDados();